// Test script per la soluzione serverless MongoDB
// Questo file contiene test per verificare l'integrazione tra frontend e backend

// Configurazione dei test
const TEST_CONFIG = {
  apiUrl: 'http://localhost:3000/api',
  testUser: {
    email: 'test@example.com',
    password: 'password123',
    name: 'Utente Test'
  },
  testClient: {
    name: 'Cliente Test',
    email: 'cliente@example.com',
    phone: '+39 123 456 7890',
    address: 'Via Test 123, Test',
    notes: 'Cliente creato per test'
  },
  testOrder: {
    order_number: 'ORD-TEST-001',
    status: 'pending',
    notes: 'Ordine creato per test'
  },
  testOrderItem: {
    product_code: 'PROD-001',
    description: 'Prodotto di test',
    quantity: 2,
    unit_price: 100,
    unit_cost: 70,
    supplier: 'Fornitore Test'
  }
};

// Classe per i test
class MongoDBIntegrationTests {
  constructor() {
    this.apiUrl = TEST_CONFIG.apiUrl;
    this.token = null;
    this.userId = null;
    this.testClientId = null;
    this.testOrderId = null;
    this.testOrderItemId = null;
    this.results = {
      passed: 0,
      failed: 0,
      total: 0
    };
  }

  // Metodo per eseguire una richiesta API
  async apiRequest(endpoint, method = 'GET', data = null) {
    const headers = {
      'Content-Type': 'application/json'
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const options = {
      method,
      headers
    };

    if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
      options.body = JSON.stringify(data);
    }

    try {
      const response = await fetch(`${this.apiUrl}${endpoint}`, options);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Errore ${response.status}: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error(`Errore durante la richiesta API a ${endpoint}:`, error);
      throw error;
    }
  }

  // Metodo per eseguire un test
  async runTest(name, testFunction) {
    console.log(`Esecuzione test: ${name}`);
    this.results.total++;
    
    try {
      await testFunction();
      console.log(`✅ Test passato: ${name}`);
      this.results.passed++;
      return true;
    } catch (error) {
      console.error(`❌ Test fallito: ${name}`);
      console.error(error);
      this.results.failed++;
      return false;
    }
  }

  // Test di connessione al backend
  async testConnection() {
    return this.runTest('Connessione al backend', async () => {
      const response = await fetch(`${this.apiUrl}/config/test-connection`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ test: true })
      });
      
      if (!response.ok) {
        throw new Error(`Errore ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      console.log('Risposta test connessione:', data);
    });
  }

  // Test di registrazione utente
  async testRegister() {
    return this.runTest('Registrazione utente', async () => {
      const data = await this.apiRequest('/auth/register', 'POST', {
        email: TEST_CONFIG.testUser.email,
        password: TEST_CONFIG.testUser.password,
        name: TEST_CONFIG.testUser.name
      });
      
      if (!data.token || !data.user || !data.user.id) {
        throw new Error('Registrazione fallita: dati utente o token mancanti');
      }
      
      this.token = data.token;
      this.userId = data.user.id;
      console.log('Utente registrato con ID:', this.userId);
    });
  }

  // Test di login utente
  async testLogin() {
    return this.runTest('Login utente', async () => {
      const data = await this.apiRequest('/auth/login', 'POST', {
        email: TEST_CONFIG.testUser.email,
        password: TEST_CONFIG.testUser.password
      });
      
      if (!data.token || !data.user || !data.user.id) {
        throw new Error('Login fallito: dati utente o token mancanti');
      }
      
      this.token = data.token;
      this.userId = data.user.id;
      console.log('Utente loggato con ID:', this.userId);
    });
  }

  // Test di recupero utente corrente
  async testGetCurrentUser() {
    return this.runTest('Recupero utente corrente', async () => {
      const user = await this.apiRequest('/auth/user');
      
      if (!user || !user._id) {
        throw new Error('Recupero utente fallito: dati utente mancanti');
      }
      
      console.log('Utente corrente:', user);
    });
  }

  // Test di creazione cliente
  async testCreateClient() {
    return this.runTest('Creazione cliente', async () => {
      const client = await this.apiRequest('/clients', 'POST', TEST_CONFIG.testClient);
      
      if (!client || !client.id) {
        throw new Error('Creazione cliente fallita: dati cliente mancanti');
      }
      
      this.testClientId = client.id;
      console.log('Cliente creato con ID:', this.testClientId);
    });
  }

  // Test di recupero clienti
  async testGetClients() {
    return this.runTest('Recupero clienti', async () => {
      const response = await this.apiRequest('/clients');
      
      if (!response || !response.data || !Array.isArray(response.data)) {
        throw new Error('Recupero clienti fallito: dati mancanti o formato non valido');
      }
      
      console.log(`Recuperati ${response.data.length} clienti`);
    });
  }

  // Test di recupero cliente specifico
  async testGetClient() {
    return this.runTest('Recupero cliente specifico', async () => {
      if (!this.testClientId) {
        throw new Error('ID cliente non disponibile per il test');
      }
      
      const client = await this.apiRequest(`/clients/${this.testClientId}`);
      
      if (!client || !client._id) {
        throw new Error('Recupero cliente fallito: dati cliente mancanti');
      }
      
      console.log('Cliente recuperato:', client);
    });
  }

  // Test di aggiornamento cliente
  async testUpdateClient() {
    return this.runTest('Aggiornamento cliente', async () => {
      if (!this.testClientId) {
        throw new Error('ID cliente non disponibile per il test');
      }
      
      const updatedClient = {
        ...TEST_CONFIG.testClient,
        name: 'Cliente Test Aggiornato',
        notes: 'Note aggiornate per test'
      };
      
      const client = await this.apiRequest(`/clients/${this.testClientId}`, 'PUT', updatedClient);
      
      if (!client || !client.id || client.name !== 'Cliente Test Aggiornato') {
        throw new Error('Aggiornamento cliente fallito: dati cliente non aggiornati');
      }
      
      console.log('Cliente aggiornato:', client);
    });
  }

  // Test di creazione ordine
  async testCreateOrder() {
    return this.runTest('Creazione ordine', async () => {
      if (!this.testClientId) {
        throw new Error('ID cliente non disponibile per il test');
      }
      
      const orderData = {
        ...TEST_CONFIG.testOrder,
        client_id: this.testClientId
      };
      
      const order = await this.apiRequest('/orders', 'POST', orderData);
      
      if (!order || !order.id) {
        throw new Error('Creazione ordine fallita: dati ordine mancanti');
      }
      
      this.testOrderId = order.id;
      console.log('Ordine creato con ID:', this.testOrderId);
    });
  }

  // Test di recupero ordini
  async testGetOrders() {
    return this.runTest('Recupero ordini', async () => {
      const response = await this.apiRequest('/orders');
      
      if (!response || !response.data || !Array.isArray(response.data)) {
        throw new Error('Recupero ordini fallito: dati mancanti o formato non valido');
      }
      
      console.log(`Recuperati ${response.data.length} ordini`);
    });
  }

  // Test di recupero ordine specifico
  async testGetOrder() {
    return this.runTest('Recupero ordine specifico', async () => {
      if (!this.testOrderId) {
        throw new Error('ID ordine non disponibile per il test');
      }
      
      const order = await this.apiRequest(`/orders/${this.testOrderId}`);
      
      if (!order || !order._id) {
        throw new Error('Recupero ordine fallito: dati ordine mancanti');
      }
      
      console.log('Ordine recuperato:', order);
    });
  }

  // Test di aggiornamento ordine
  async testUpdateOrder() {
    return this.runTest('Aggiornamento ordine', async () => {
      if (!this.testOrderId || !this.testClientId) {
        throw new Error('ID ordine o cliente non disponibile per il test');
      }
      
      const updatedOrder = {
        ...TEST_CONFIG.testOrder,
        client_id: this.testClientId,
        status: 'processing',
        notes: 'Note aggiornate per test'
      };
      
      const order = await this.apiRequest(`/orders/${this.testOrderId}`, 'PUT', updatedOrder);
      
      if (!order || !order.id || order.status !== 'processing') {
        throw new Error('Aggiornamento ordine fallito: dati ordine non aggiornati');
      }
      
      console.log('Ordine aggiornato:', order);
    });
  }

  // Test di creazione elemento ordine
  async testCreateOrderItem() {
    return this.runTest('Creazione elemento ordine', async () => {
      if (!this.testOrderId) {
        throw new Error('ID ordine non disponibile per il test');
      }
      
      const orderItem = await this.apiRequest(`/orders/${this.testOrderId}/items`, 'POST', TEST_CONFIG.testOrderItem);
      
      if (!orderItem || !orderItem.id) {
        throw new Error('Creazione elemento ordine fallita: dati elemento mancanti');
      }
      
      this.testOrderItemId = orderItem.id;
      console.log('Elemento ordine creato con ID:', this.testOrderItemId);
    });
  }

  // Test di recupero elementi ordine
  async testGetOrderItems() {
    return this.runTest('Recupero elementi ordine', async () => {
      if (!this.testOrderId) {
        throw new Error('ID ordine non disponibile per il test');
      }
      
      const items = await this.apiRequest(`/orders/${this.testOrderId}/items`);
      
      if (!items || !Array.isArray(items)) {
        throw new Error('Recupero elementi ordine fallito: dati mancanti o formato non valido');
      }
      
      console.log(`Recuperati ${items.length} elementi ordine`);
    });
  }

  // Test di aggiornamento elemento ordine
  async testUpdateOrderItem() {
    return this.runTest('Aggiornamento elemento ordine', async () => {
      if (!this.testOrderId || !this.testOrderItemId) {
        throw new Error('ID ordine o elemento non disponibile per il test');
      }
      
      const updatedItem = {
        ...TEST_CONFIG.testOrderItem,
        quantity: 3,
        description: 'Prodotto di test aggiornato'
      };
      
      const item = await this.apiRequest(`/orders/${this.testOrderId}/items/${this.testOrderItemId}`, 'PUT', updatedItem);
      
      if (!item || !item.id || item.quantity !== 3) {
        throw new Error('Aggiornamento elemento ordine fallito: dati elemento non aggiornati');
      }
      
      console.log('Elemento ordine aggiornato:', item);
    });
  }

  // Test di recupero statistiche dashboard
  async testGetDashboardStats() {
    return this.runTest('Recupero statistiche dashboard', async () => {
      const stats = await this.apiRequest('/stats/dashboard');
      
      if (!stats || typeof stats.totalClients === 'undefined') {
        throw new Error('Recupero statistiche dashboard fallito: dati mancanti');
      }
      
      console.log('Statistiche dashboard:', stats);
    });
  }

  // Test di recupero statistiche clienti
  async testGetClientStats() {
    return this.runTest('Recupero statistiche clienti', async () => {
      const stats = await this.apiRequest('/stats/clients');
      
      if (!stats || typeof stats.totalClients === 'undefined') {
        throw new Error('Recupero statistiche clienti fallito: dati mancanti');
      }
      
      console.log('Statistiche clienti:', stats);
    });
  }

  // Test di recupero statistiche ordini
  async testGetOrderStats() {
    return this.runTest('Recupero statistiche ordini', async () => {
      const stats = await this.apiRequest('/stats/orders');
      
      if (!stats || typeof stats.totalOrders === 'undefined') {
        throw new Error('Recupero statistiche ordini fallito: dati mancanti');
      }
      
      console.log('Statistiche ordini:', stats);
    });
  }

  // Test di pulizia (elimina dati di test)
  async testCleanup() {
    return this.runTest('Pulizia dati di test', async () => {
      // Elimina elemento ordine
      if (this.testOrderItemId && this.testOrderId) {
        await this.apiRequest(`/orders/${this.testOrderId}/items/${this.testOrderItemId}`, 'DELETE');
        console.log('Elemento ordine eliminato');
      }
      
      // Elimina ordine
      if (this.testOrderId) {
        await this.apiRequest(`/orders/${this.testOrderId}`, 'DELETE');
        console.log('Ordine eliminato');
      }
      
      // Elimina cliente
      if (this.testClientId) {
        await this.apiRequest(`/clients/${this.testClientId}`, 'DELETE');
        console.log('Cliente eliminato');
      }
    });
  }

  // Esegui tutti i test
  async runAllTests() {
    console.log('Inizio dei test di integrazione MongoDB...');
    
    // Test di connessione
    await this.testConnection();
    
    // Test di autenticazione
    let authSuccess = false;
    try {
      await this.testRegister();
      authSuccess = true;
    } catch (error) {
      console.log('Registrazione fallita, tentativo di login...');
      try {
        await this.testLogin();
        authSuccess = true;
      } catch (loginError) {
        console.error('Impossibile autenticarsi, i test successivi falliranno');
      }
    }
    
    if (authSuccess) {
      await this.testGetCurrentUser();
      
      // Test di gestione clienti
      await this.testCreateClient();
      await this.testGetClients();
      await this.testGetClient();
      await this.testUpdateClient();
      
      // Test di gestione ordini
      await this.testCreateOrder();
      await this.testGetOrders();
      await this.testGetOrder();
      await this.testUpdateOrder();
      
      // Test di gestione elementi ordine
      await this.testCreateOrderItem();
      await this.testGetOrderItems();
      await this.testUpdateOrderItem();
      
      // Test di statistiche
      await this.testGetDashboardStats();
      await this.testGetClientStats();
      await this.testGetOrderStats();
      
      // Pulizia
      await this.testCleanup();
    }
    
    // Risultati finali
    console.log('Test completati!');
    console.log(`Passati: ${this.results.passed}/${this.results.total} (${Math.round(this.results.passed / this.results.total * 100)}%)`);
    console.log(`Falliti: ${this.results.failed}/${this.results.total} (${Math.round(this.results.failed / this.results.total * 100)}%)`);
    
    return {
      success: this.results.failed === 0,
      results: this.results
    };
  }
}

// Esporta la classe di test
window.MongoDBIntegrationTests = MongoDBIntegrationTests;

// Funzione per eseguire i test
window.runMongoDBTests = async function(apiUrl = null) {
  if (apiUrl) {
    TEST_CONFIG.apiUrl = apiUrl;
  }
  
  const tester = new MongoDBIntegrationTests();
  return await tester.runAllTests();
};
