// MongoDB Frontend Integration for Client Pulse CRM
// Questo file sostituisce supabase.js e si integra con il backend serverless MongoDB

class MongoDBService {
  constructor() {
    // URL di base per l'API serverless
    this.apiBaseUrl = 'https://api.clientpulse.com/api'; // Sostituire con l'URL effettivo del backend
    this.token = localStorage.getItem('auth_token');
    this.currentUser = null;
  }

  // Inizializza il servizio
  async init() {
    if (this.token) {
      try {
        this.currentUser = await this.getCurrentUser();
        return true;
      } catch (error) {
        console.error('Errore durante l\'inizializzazione:', error);
        this.logout();
        return false;
      }
    }
    return false;
  }

  // Configura l'URL dell'API
  setApiUrl(url) {
    this.apiBaseUrl = url;
    localStorage.setItem('api_url', url);
  }

  // Ottieni l'URL dell'API
  getApiUrl() {
    return this.apiBaseUrl || localStorage.getItem('api_url');
  }

  // Metodo generico per le richieste API
  async apiRequest(endpoint, method = 'GET', data = null) {
    const headers = {
      'Content-Type': 'application/json'
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const options = {
      method,
      headers
    };

    if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
      options.body = JSON.stringify(data);
    }

    try {
      const response = await fetch(`${this.apiBaseUrl}${endpoint}`, options);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Errore ${response.status}: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error(`Errore durante la richiesta API a ${endpoint}:`, error);
      throw error;
    }
  }

  // AUTENTICAZIONE

  // Registrazione utente
  async register(email, password, userData = {}) {
    try {
      const data = await this.apiRequest('/auth/register', 'POST', {
        email,
        password,
        ...userData
      });
      
      this.token = data.token;
      this.currentUser = data.user;
      localStorage.setItem('auth_token', this.token);
      
      return data.user;
    } catch (error) {
      console.error('Errore durante la registrazione:', error);
      throw error;
    }
  }

  // Login utente
  async login(email, password) {
    try {
      const data = await this.apiRequest('/auth/login', 'POST', {
        email,
        password
      });
      
      this.token = data.token;
      this.currentUser = data.user;
      localStorage.setItem('auth_token', this.token);
      
      return data.user;
    } catch (error) {
      console.error('Errore durante il login:', error);
      throw error;
    }
  }

  // Logout utente
  logout() {
    this.token = null;
    this.currentUser = null;
    localStorage.removeItem('auth_token');
  }

  // Ottieni utente corrente
  async getCurrentUser() {
    if (!this.token) return null;
    
    try {
      return await this.apiRequest('/auth/user');
    } catch (error) {
      console.error('Errore durante il recupero dell\'utente corrente:', error);
      this.logout();
      throw error;
    }
  }

  // Verifica se l'utente è autenticato
  isAuthenticated() {
    return !!this.token;
  }

  // GESTIONE CLIENTI

  // Ottieni tutti i clienti
  async getClients(options = {}) {
    try {
      const { filters, sort, limit, skip } = options;
      let endpoint = '/clients';
      
      // Costruisci query string
      const queryParams = new URLSearchParams();
      
      if (filters) {
        Object.entries(filters).forEach(([key, value]) => {
          if (value !== undefined && value !== null) {
            queryParams.append(key, value);
          }
        });
      }
      
      if (sort) {
        queryParams.append('sort', sort);
      }
      
      if (limit) {
        queryParams.append('limit', limit);
      }
      
      if (skip) {
        queryParams.append('skip', skip);
      }
      
      if (queryParams.toString()) {
        endpoint += `?${queryParams.toString()}`;
      }
      
      const response = await this.apiRequest(endpoint);
      return response.data || [];
    } catch (error) {
      console.error('Errore durante il recupero dei clienti:', error);
      throw error;
    }
  }

  // Ottieni un cliente specifico
  async getClient(id) {
    try {
      return await this.apiRequest(`/clients/${id}`);
    } catch (error) {
      console.error(`Errore durante il recupero del cliente ${id}:`, error);
      throw error;
    }
  }

  // Crea un nuovo cliente
  async createClient(clientData) {
    try {
      return await this.apiRequest('/clients', 'POST', clientData);
    } catch (error) {
      console.error('Errore durante la creazione del cliente:', error);
      throw error;
    }
  }

  // Aggiorna un cliente esistente
  async updateClient(id, clientData) {
    try {
      return await this.apiRequest(`/clients/${id}`, 'PUT', clientData);
    } catch (error) {
      console.error(`Errore durante l'aggiornamento del cliente ${id}:`, error);
      throw error;
    }
  }

  // Elimina un cliente
  async deleteClient(id) {
    try {
      return await this.apiRequest(`/clients/${id}`, 'DELETE');
    } catch (error) {
      console.error(`Errore durante l'eliminazione del cliente ${id}:`, error);
      throw error;
    }
  }

  // GESTIONE ORDINI

  // Ottieni tutti gli ordini
  async getOrders(options = {}) {
    try {
      const { filters, sort, limit, skip } = options;
      let endpoint = '/orders';
      
      // Costruisci query string
      const queryParams = new URLSearchParams();
      
      if (filters) {
        Object.entries(filters).forEach(([key, value]) => {
          if (value !== undefined && value !== null) {
            queryParams.append(key, value);
          }
        });
      }
      
      if (sort) {
        queryParams.append('sort', sort);
      }
      
      if (limit) {
        queryParams.append('limit', limit);
      }
      
      if (skip) {
        queryParams.append('skip', skip);
      }
      
      if (queryParams.toString()) {
        endpoint += `?${queryParams.toString()}`;
      }
      
      const response = await this.apiRequest(endpoint);
      return response.data || [];
    } catch (error) {
      console.error('Errore durante il recupero degli ordini:', error);
      throw error;
    }
  }

  // Ottieni un ordine specifico
  async getOrder(id) {
    try {
      return await this.apiRequest(`/orders/${id}`);
    } catch (error) {
      console.error(`Errore durante il recupero dell'ordine ${id}:`, error);
      throw error;
    }
  }

  // Crea un nuovo ordine
  async createOrder(orderData) {
    try {
      return await this.apiRequest('/orders', 'POST', orderData);
    } catch (error) {
      console.error('Errore durante la creazione dell\'ordine:', error);
      throw error;
    }
  }

  // Aggiorna un ordine esistente
  async updateOrder(id, orderData) {
    try {
      return await this.apiRequest(`/orders/${id}`, 'PUT', orderData);
    } catch (error) {
      console.error(`Errore durante l'aggiornamento dell'ordine ${id}:`, error);
      throw error;
    }
  }

  // Elimina un ordine
  async deleteOrder(id) {
    try {
      return await this.apiRequest(`/orders/${id}`, 'DELETE');
    } catch (error) {
      console.error(`Errore durante l'eliminazione dell'ordine ${id}:`, error);
      throw error;
    }
  }

  // GESTIONE ELEMENTI ORDINE

  // Ottieni tutti gli elementi di un ordine
  async getOrderItems(orderId) {
    try {
      return await this.apiRequest(`/orders/${orderId}/items`);
    } catch (error) {
      console.error(`Errore durante il recupero degli elementi dell'ordine ${orderId}:`, error);
      throw error;
    }
  }

  // Aggiungi un elemento a un ordine
  async addOrderItem(orderId, itemData) {
    try {
      return await this.apiRequest(`/orders/${orderId}/items`, 'POST', itemData);
    } catch (error) {
      console.error(`Errore durante l'aggiunta di un elemento all'ordine ${orderId}:`, error);
      throw error;
    }
  }

  // Aggiorna un elemento di un ordine
  async updateOrderItem(orderId, itemId, itemData) {
    try {
      return await this.apiRequest(`/orders/${orderId}/items/${itemId}`, 'PUT', itemData);
    } catch (error) {
      console.error(`Errore durante l'aggiornamento dell'elemento ${itemId} dell'ordine ${orderId}:`, error);
      throw error;
    }
  }

  // Elimina un elemento di un ordine
  async deleteOrderItem(orderId, itemId) {
    try {
      return await this.apiRequest(`/orders/${orderId}/items/${itemId}`, 'DELETE');
    } catch (error) {
      console.error(`Errore durante l'eliminazione dell'elemento ${itemId} dell'ordine ${orderId}:`, error);
      throw error;
    }
  }

  // IMPORTAZIONE/ESPORTAZIONE

  // Importa clienti da Excel
  async importClientsFromExcel(excelData) {
    try {
      return await this.apiRequest('/import/clients', 'POST', { data: excelData });
    } catch (error) {
      console.error('Errore durante l\'importazione dei clienti da Excel:', error);
      throw error;
    }
  }

  // Importa ordini da Excel
  async importOrdersFromExcel(excelData) {
    try {
      return await this.apiRequest('/import/orders', 'POST', { data: excelData });
    } catch (error) {
      console.error('Errore durante l\'importazione degli ordini da Excel:', error);
      throw error;
    }
  }

  // STATISTICHE

  // Ottieni statistiche per la dashboard
  async getDashboardStats() {
    try {
      return await this.apiRequest('/stats/dashboard');
    } catch (error) {
      console.error('Errore durante il recupero delle statistiche della dashboard:', error);
      throw error;
    }
  }

  // Ottieni statistiche dei clienti
  async getClientStats() {
    try {
      return await this.apiRequest('/stats/clients');
    } catch (error) {
      console.error('Errore durante il recupero delle statistiche dei clienti:', error);
      throw error;
    }
  }

  // Ottieni statistiche degli ordini
  async getOrderStats() {
    try {
      return await this.apiRequest('/stats/orders');
    } catch (error) {
      console.error('Errore durante il recupero delle statistiche degli ordini:', error);
      throw error;
    }
  }

  // TEST CONNESSIONE

  // Testa la connessione al backend
  async testConnection() {
    try {
      const response = await fetch(`${this.apiBaseUrl}/config/test-connection`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ test: true })
      });
      
      if (!response.ok) {
        throw new Error(`Errore ${response.status}: ${response.statusText}`);
      }
      
      return true;
    } catch (error) {
      console.error('Errore durante il test della connessione:', error);
      return false;
    }
  }
}

// Inizializza e esporta il servizio MongoDB
const mongoDBService = new MongoDBService();

// Funzione per mostrare il form di configurazione
function showConfigForm() {
  // Crea un modale per la configurazione
  const modal = document.createElement('div');
  modal.className = 'modal active';
  modal.id = 'mongodb-config-modal';
  
  modal.innerHTML = `
    <div class="modal-content">
      <h2>Configurazione API Backend</h2>
      <p>Per utilizzare l'applicazione, è necessario configurare la connessione al backend serverless.</p>
      <form id="api-config-form">
        <div class="form-group">
          <label for="api-url">URL API Backend</label>
          <input type="text" id="api-url" placeholder="https://api.clientpulse.com/api" required>
          <small>Inserisci l'URL del backend serverless MongoDB.</small>
        </div>
        <div class="form-actions">
          <button type="submit" class="btn btn-primary">Salva e Connetti</button>
        </div>
      </form>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  // Gestione dell'invio del form
  document.getElementById('api-config-form').addEventListener('submit', async function(event) {
    event.preventDefault();
    
    const apiUrl = document.getElementById('api-url').value;
    
    // Salva l'URL dell'API
    mongoDBService.setApiUrl(apiUrl);
    
    // Testa la connessione
    const success = await mongoDBService.testConnection();
    
    if (success) {
      document.body.removeChild(modal);
      window.location.reload();
    } else {
      alert('Impossibile connettersi al backend. Verifica l\'URL e riprova.');
    }
  });
}

// Esporta il servizio e le funzioni
window.mongoDBService = mongoDBService;
window.showMongoDBConfigForm = showConfigForm;

// Inizializza automaticamente
document.addEventListener('DOMContentLoaded', async () => {
  const apiUrl = localStorage.getItem('api_url');
  
  if (!apiUrl) {
    showConfigForm();
  } else {
    mongoDBService.setApiUrl(apiUrl);
    await mongoDBService.init();
  }
});
