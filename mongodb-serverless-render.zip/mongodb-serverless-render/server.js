// MongoDB Serverless Backend for Client Pulse CRM
// server.js - Main entry point for the serverless backend

const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const xlsx = require('xlsx');
const path = require('path');
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

// Initialize Express app
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB connection
let db;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://your-mongodb-uri';
const DB_NAME = process.env.DB_NAME || 'clientPulseCRM';
const JWT_SECRET = process.env.JWT_SECRET || 'your-jwt-secret';

// Connect to MongoDB
async function connectToMongoDB() {
  try {
    const client = new MongoClient(MONGODB_URI);
    await client.connect();
    console.log('Connected to MongoDB');
    db = client.db(DB_NAME);
    
    // Create indexes for better performance
    await db.collection('clients').createIndex({ name: 1 });
    await db.collection('clients').createIndex({ email: 1 });
    await db.collection('orders').createIndex({ client_id: 1 });
    await db.collection('orders').createIndex({ order_date: 1 });
    await db.collection('users').createIndex({ email: 1 }, { unique: true });
    
    return true;
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
    return false;
  }
}

// Health check endpoint for Render
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'ok', message: 'Server is running' });
});

// Demo initialization endpoint
app.get('/api/init-demo', async (req, res) => {
  try {
    const { populateDemoDatabase } = require('./demo-setup');
    const result = await populateDemoDatabase();
    
    if (result) {
      res.status(200).json({ status: 'ok', message: 'Demo database initialized successfully' });
    } else {
      res.status(500).json({ status: 'error', message: 'Failed to initialize demo database' });
    }
  } catch (error) {
    console.error('Error initializing demo database:', error);
    res.status(500).json({ status: 'error', message: 'Error initializing demo database', error: error.message });
  }
});

// Middleware to verify JWT token
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: 'Unauthorized: Token missing' });
  }
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Forbidden: Invalid token' });
    }
    
    req.user = user;
    next();
  });
}

// Authentication routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    
    // Check if user already exists
    const existingUser = await db.collection('users').findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // Create new user
    const newUser = {
      email,
      password: hashedPassword,
      name,
      created_at: new Date(),
      updated_at: new Date()
    };
    
    const result = await db.collection('users').insertOne(newUser);
    
    // Generate JWT token
    const token = jwt.sign({ id: result.insertedId, email }, JWT_SECRET, { expiresIn: '24h' });
    
    res.status(201).json({
      token,
      user: {
        id: result.insertedId,
        email,
        name
      }
    });
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const user = await db.collection('users').findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Verify password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Generate JWT token
    const token = jwt.sign({ id: user._id, email }, JWT_SECRET, { expiresIn: '24h' });
    
    res.json({
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name
      }
    });
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/auth/user', authenticateToken, async (req, res) => {
  try {
    const user = await db.collection('users').findOne(
      { _id: new ObjectId(req.user.id) },
      { projection: { password: 0 } }
    );
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    res.json(user);
  } catch (error) {
    console.error('Error getting user:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Client routes
app.get('/api/clients', authenticateToken, async (req, res) => {
  try {
    const { status, search, sort, limit = 100, skip = 0 } = req.query;
    
    // Build query
    const query = {};
    
    if (status) {
      query.status = status;
    }
    
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { phone: { $regex: search, $options: 'i' } }
      ];
    }
    
    // Build sort
    const sortOptions = {};
    if (sort) {
      const [field, order] = sort.split(':');
      sortOptions[field] = order === 'desc' ? -1 : 1;
    } else {
      sortOptions.name = 1;
    }
    
    // Get clients
    const clients = await db.collection('clients')
      .find(query)
      .sort(sortOptions)
      .skip(parseInt(skip))
      .limit(parseInt(limit))
      .toArray();
    
    // Get total count
    const total = await db.collection('clients').countDocuments(query);
    
    res.json({
      data: clients,
      total,
      limit: parseInt(limit),
      skip: parseInt(skip)
    });
  } catch (error) {
    console.error('Error getting clients:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/clients/:id', authenticateToken, async (req, res) => {
  try {
    const client = await db.collection('clients').findOne({ _id: new ObjectId(req.params.id) });
    
    if (!client) {
      return res.status(404).json({ message: 'Client not found' });
    }
    
    res.json(client);
  } catch (error) {
    console.error('Error getting client:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/clients', authenticateToken, async (req, res) => {
  try {
    const { name, email, phone, address, notes, status } = req.body;
    
    // Validate required fields
    if (!name) {
      return res.status(400).json({ message: 'Name is required' });
    }
    
    // Create new client
    const newClient = {
      name,
      email,
      phone,
      address,
      notes,
      status: status || 'active',
      last_purchase: null,
      created_at: new Date(),
      updated_at: new Date()
    };
    
    const result = await db.collection('clients').insertOne(newClient);
    
    res.status(201).json({
      id: result.insertedId,
      ...newClient
    });
  } catch (error) {
    console.error('Error creating client:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.put('/api/clients/:id', authenticateToken, async (req, res) => {
  try {
    const { name, email, phone, address, notes, status, last_purchase } = req.body;
    
    // Validate required fields
    if (!name) {
      return res.status(400).json({ message: 'Name is required' });
    }
    
    // Update client
    const updatedClient = {
      name,
      email,
      phone,
      address,
      notes,
      status,
      last_purchase: last_purchase ? new Date(last_purchase) : null,
      updated_at: new Date()
    };
    
    const result = await db.collection('clients').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: updatedClient }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Client not found' });
    }
    
    res.json({
      id: req.params.id,
      ...updatedClient
    });
  } catch (error) {
    console.error('Error updating client:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.delete('/api/clients/:id', authenticateToken, async (req, res) => {
  try {
    // Check if client has orders
    const orders = await db.collection('orders').findOne({ client_id: req.params.id });
    if (orders) {
      return res.status(400).json({ message: 'Cannot delete client with orders' });
    }
    
    const result = await db.collection('clients').deleteOne({ _id: new ObjectId(req.params.id) });
    
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: 'Client not found' });
    }
    
    res.json({ message: 'Client deleted successfully' });
  } catch (error) {
    console.error('Error deleting client:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Order routes
app.get('/api/orders', authenticateToken, async (req, res) => {
  try {
    const { client_id, status, search, sort, limit = 100, skip = 0 } = req.query;
    
    // Build query
    const query = {};
    
    if (client_id) {
      query.client_id = client_id;
    }
    
    if (status) {
      query.status = status;
    }
    
    if (search) {
      query.$or = [
        { order_number: { $regex: search, $options: 'i' } },
        { notes: { $regex: search, $options: 'i' } }
      ];
    }
    
    // Build sort
    const sortOptions = {};
    if (sort) {
      const [field, order] = sort.split(':');
      sortOptions[field] = order === 'desc' ? -1 : 1;
    } else {
      sortOptions.order_date = -1;
    }
    
    // Get orders
    const orders = await db.collection('orders')
      .find(query)
      .sort(sortOptions)
      .skip(parseInt(skip))
      .limit(parseInt(limit))
      .toArray();
    
    // Get total count
    const total = await db.collection('orders').countDocuments(query);
    
    // Get client details for each order
    const ordersWithClientDetails = await Promise.all(orders.map(async (order) => {
      if (order.client_id) {
        const client = await db.collection('clients').findOne(
          { _id: new ObjectId(order.client_id) },
          { projection: { name: 1, email: 1 } }
        );
        
        return {
          ...order,
          client: client || { name: 'Unknown', email: 'Unknown' }
        };
      }
      
      return order;
    }));
    
    res.json({
      data: ordersWithClientDetails,
      total,
      limit: parseInt(limit),
      skip: parseInt(skip)
    });
  } catch (error) {
    console.error('Error getting orders:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/orders/:id', authenticateToken, async (req, res) => {
  try {
    const order = await db.collection('orders').findOne({ _id: new ObjectId(req.params.id) });
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    // Get client details
    let client = null;
    if (order.client_id) {
      client = await db.collection('clients').findOne(
        { _id: new ObjectId(order.client_id) },
        { projection: { name: 1, email: 1, phone: 1 } }
      );
    }
    
    // Get order items
    const items = await db.collection('orderItems')
      .find({ order_id: req.params.id })
      .toArray();
    
    res.json({
      ...order,
      client,
      items
    });
  } catch (error) {
    console.error('Error getting order:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/orders', authenticateToken, async (req, res) => {
  try {
    const {
      client_id,
      order_number,
      order_date,
      delivery_date,
      status,
      total_amount,
      total_cost,
      profit,
      notes,
      items
    } = req.body;
    
    // Validate required fields
    if (!client_id) {
      return res.status(400).json({ message: 'Client ID is required' });
    }
    
    // Create new order
    const newOrder = {
      client_id,
      order_number: order_number || `ORD-${Date.now()}`,
      order_date: order_date ? new Date(order_date) : new Date(),
      delivery_date: delivery_date ? new Date(delivery_date) : null,
      status: status || 'pending',
      total_amount: total_amount || 0,
      total_cost: total_cost || 0,
      profit: profit || 0,
      notes,
      created_at: new Date(),
      updated_at: new Date()
    };
    
    const result = await db.collection('orders').insertOne(newOrder);
    const orderId = result.insertedId.toString();
    
    // Add order items if provided
    if (items && items.length > 0) {
      const orderItems = items.map(item => ({
        order_id: orderId,
        product_code: item.product_code,
        description: item.description,
        quantity: item.quantity,
        unit_price: item.unit_price,
        unit_cost: item.unit_cost,
        total_price: item.total_price,
        total_cost: item.total_cost,
        profit: item.profit,
        supplier: item.supplier,
        created_at: new Date(),
        updated_at: new Date()
      }));
      
      await db.collection('orderItems').insertMany(orderItems);
    }
    
    // Update client's last purchase date
    await db.collection('clients').updateOne(
      { _id: new ObjectId(client_id) },
      { $set: { last_purchase: new Date(), updated_at: new Date() } }
    );
    
    res.status(201).json({
      id: orderId,
      ...newOrder,
      items: items || []
    });
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.put('/api/orders/:id', authenticateToken, async (req, res) => {
  try {
    const {
      client_id,
      order_number,
      order_date,
      delivery_date,
      status,
      total_amount,
      total_cost,
      profit,
      notes
    } = req.body;
    
    // Validate required fields
    if (!client_id) {
      return res.status(400).json({ message: 'Client ID is required' });
    }
    
    // Update order
    const updatedOrder = {
      client_id,
      order_number,
      order_date: order_date ? new Date(order_date) : new Date(),
      delivery_date: delivery_date ? new Date(delivery_date) : null,
      status,
      total_amount,
      total_cost,
      profit,
      notes,
      updated_at: new Date()
    };
    
    const result = await db.collection('orders').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: updatedOrder }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    res.json({
      id: req.params.id,
      ...updatedOrder
    });
  } catch (error) {
    console.error('Error updating order:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.delete('/api/orders/:id', authenticateToken, async (req, res) => {
  try {
    // Delete order items first
    await db.collection('orderItems').deleteMany({ order_id: req.params.id });
    
    // Delete order
    const result = await db.collection('orders').deleteOne({ _id: new ObjectId(req.params.id) });
    
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    res.json({ message: 'Order deleted successfully' });
  } catch (error) {
    console.error('Error deleting order:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Order items routes
app.get('/api/orders/:orderId/items', authenticateToken, async (req, res) => {
  try {
    const items = await db.collection('orderItems')
      .find({ order_id: req.params.orderId })
      .toArray();
    
    res.json(items);
  } catch (error) {
    console.error('Error getting order items:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/orders/:orderId/items', authenticateToken, async (req, res) => {
  try {
    const {
      product_code,
      description,
      quantity,
      unit_price,
      unit_cost,
      total_price,
      total_cost,
      profit,
      supplier
    } = req.body;
    
    // Validate required fields
    if (!product_code || !quantity || !unit_price) {
      return res.status(400).json({ message: 'Product code, quantity, and unit price are required' });
    }
    
    // Create new order item
    const newItem = {
      order_id: req.params.orderId,
      product_code,
      description,
      quantity,
      unit_price,
      unit_cost: unit_cost || 0,
      total_price: total_price || (quantity * unit_price),
      total_cost: total_cost || (quantity * (unit_cost || 0)),
      profit: profit || (total_price - total_cost),
      supplier,
      created_at: new Date(),
      updated_at: new Date()
    };
    
    const result = await db.collection('orderItems').insertOne(newItem);
    
    // Update order totals
    const items = await db.collection('orderItems')
      .find({ order_id: req.params.orderId })
      .toArray();
    
    const totalAmount = items.reduce((sum, item) => sum + item.total_price, 0);
    const totalCost = items.reduce((sum, item) => sum + item.total_cost, 0);
    const totalProfit = totalAmount - totalCost;
    
    await db.collection('orders').updateOne(
      { _id: new ObjectId(req.params.orderId) },
      {
        $set: {
          total_amount: totalAmount,
          total_cost: totalCost,
          profit: totalProfit,
          updated_at: new Date()
        }
      }
    );
    
    res.status(201).json({
      id: result.insertedId,
      ...newItem
    });
  } catch (error) {
    console.error('Error creating order item:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.put('/api/orders/:orderId/items/:itemId', authenticateToken, async (req, res) => {
  try {
    const {
      product_code,
      description,
      quantity,
      unit_price,
      unit_cost,
      total_price,
      total_cost,
      profit,
      supplier
    } = req.body;
    
    // Validate required fields
    if (!product_code || !quantity || !unit_price) {
      return res.status(400).json({ message: 'Product code, quantity, and unit price are required' });
    }
    
    // Update order item
    const updatedItem = {
      product_code,
      description,
      quantity,
      unit_price,
      unit_cost: unit_cost || 0,
      total_price: total_price || (quantity * unit_price),
      total_cost: total_cost || (quantity * (unit_cost || 0)),
      profit: profit || (total_price - total_cost),
      supplier,
      updated_at: new Date()
    };
    
    const result = await db.collection('orderItems').updateOne(
      { _id: new ObjectId(req.params.itemId) },
      { $set: updatedItem }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: 'Order item not found' });
    }
    
    // Update order totals
    const items = await db.collection('orderItems')
      .find({ order_id: req.params.orderId })
      .toArray();
    
    const totalAmount = items.reduce((sum, item) => sum + item.total_price, 0);
    const totalCost = items.reduce((sum, item) => sum + item.total_cost, 0);
    const totalProfit = totalAmount - totalCost;
    
    await db.collection('orders').updateOne(
      { _id: new ObjectId(req.params.orderId) },
      {
        $set: {
          total_amount: totalAmount,
          total_cost: totalCost,
          profit: totalProfit,
          updated_at: new Date()
        }
      }
    );
    
    res.json({
      id: req.params.itemId,
      ...updatedItem
    });
  } catch (error) {
    console.error('Error updating order item:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.delete('/api/orders/:orderId/items/:itemId', authenticateToken, async (req, res) => {
  try {
    const result = await db.collection('orderItems').deleteOne({ _id: new ObjectId(req.params.itemId) });
    
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: 'Order item not found' });
    }
    
    // Update order totals
    const items = await db.collection('orderItems')
      .find({ order_id: req.params.orderId })
      .toArray();
    
    const totalAmount = items.reduce((sum, item) => sum + item.total_price, 0);
    const totalCost = items.reduce((sum, item) => sum + item.total_cost, 0);
    const totalProfit = totalAmount - totalCost;
    
    await db.collection('orders').updateOne(
      { _id: new ObjectId(req.params.orderId) },
      {
        $set: {
          total_amount: totalAmount,
          total_cost: totalCost,
          profit: totalProfit,
          updated_at: new Date()
        }
      }
    );
    
    res.json({ message: 'Order item deleted successfully' });
  } catch (error) {
    console.error('Error deleting order item:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Excel import/export routes
app.post('/api/excel/import-clients', authenticateToken, async (req, res) => {
  try {
    const { data } = req.body;
    
    if (!data || !Array.isArray(data) || data.length === 0) {
      return res.status(400).json({ message: 'Invalid data format' });
    }
    
    const clients = data.map(row => ({
      name: row.name,
      email: row.email,
      phone: row.phone,
      address: row.address,
      notes: row.notes,
      status: row.status || 'active',
      last_purchase: row.last_purchase ? new Date(row.last_purchase) : null,
      created_at: new Date(),
      updated_at: new Date()
    }));
    
    const result = await db.collection('clients').insertMany(clients);
    
    res.status(201).json({
      message: `${result.insertedCount} clients imported successfully`,
      ids: result.insertedIds
    });
  } catch (error) {
    console.error('Error importing clients:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/excel/export-clients', authenticateToken, async (req, res) => {
  try {
    const clients = await db.collection('clients').find().toArray();
    
    const data = clients.map(client => ({
      name: client.name,
      email: client.email,
      phone: client.phone,
      address: client.address,
      notes: client.notes,
      status: client.status,
      last_purchase: client.last_purchase ? client.last_purchase.toISOString() : null
    }));
    
    res.json(data);
  } catch (error) {
    console.error('Error exporting clients:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/excel/import-orders', authenticateToken, async (req, res) => {
  try {
    const { data, client_id } = req.body;
    
    if (!data || !Array.isArray(data) || data.length === 0) {
      return res.status(400).json({ message: 'Invalid data format' });
    }
    
    if (!client_id) {
      return res.status(400).json({ message: 'Client ID is required' });
    }
    
    // Create order
    const order = {
      client_id,
      order_number: `ORD-${Date.now()}`,
      order_date: new Date(),
      delivery_date: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), // 15 days from now
      status: 'pending',
      total_amount: 0,
      total_cost: 0,
      profit: 0,
      notes: 'Imported from Excel',
      created_at: new Date(),
      updated_at: new Date()
    };
    
    const orderResult = await db.collection('orders').insertOne(order);
    const orderId = orderResult.insertedId.toString();
    
    // Create order items
    const items = data.map(row => ({
      order_id: orderId,
      product_code: row.product_code,
      description: row.description,
      quantity: parseInt(row.quantity) || 1,
      unit_price: parseFloat(row.unit_price) || 0,
      unit_cost: parseFloat(row.unit_cost) || 0,
      total_price: parseFloat(row.total_price) || (parseInt(row.quantity) * parseFloat(row.unit_price)),
      total_cost: parseFloat(row.total_cost) || (parseInt(row.quantity) * parseFloat(row.unit_cost)),
      profit: parseFloat(row.profit) || (parseFloat(row.total_price) - parseFloat(row.total_cost)),
      supplier: row.supplier,
      created_at: new Date(),
      updated_at: new Date()
    }));
    
    const itemsResult = await db.collection('orderItems').insertMany(items);
    
    // Update order totals
    const totalAmount = items.reduce((sum, item) => sum + item.total_price, 0);
    const totalCost = items.reduce((sum, item) => sum + item.total_cost, 0);
    const totalProfit = totalAmount - totalCost;
    
    await db.collection('orders').updateOne(
      { _id: orderResult.insertedId },
      {
        $set: {
          total_amount: totalAmount,
          total_cost: totalCost,
          profit: totalProfit
        }
      }
    );
    
    // Update client's last purchase date
    await db.collection('clients').updateOne(
      { _id: new ObjectId(client_id) },
      { $set: { last_purchase: new Date(), updated_at: new Date() } }
    );
    
    res.status(201).json({
      message: `Order created with ${itemsResult.insertedCount} items`,
      order_id: orderId
    });
  } catch (error) {
    console.error('Error importing orders:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/excel/export-order/:id', authenticateToken, async (req, res) => {
  try {
    const order = await db.collection('orders').findOne({ _id: new ObjectId(req.params.id) });
    
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    
    // Get client details
    const client = await db.collection('clients').findOne(
      { _id: new ObjectId(order.client_id) },
      { projection: { name: 1, email: 1, phone: 1, address: 1 } }
    );
    
    // Get order items
    const items = await db.collection('orderItems')
      .find({ order_id: req.params.id })
      .toArray();
    
    const data = {
      order: {
        id: order._id.toString(),
        order_number: order.order_number,
        order_date: order.order_date.toISOString(),
        delivery_date: order.delivery_date ? order.delivery_date.toISOString() : null,
        status: order.status,
        total_amount: order.total_amount,
        total_cost: order.total_cost,
        profit: order.profit,
        notes: order.notes
      },
      client: client || { name: 'Unknown', email: 'Unknown' },
      items: items.map(item => ({
        product_code: item.product_code,
        description: item.description,
        quantity: item.quantity,
        unit_price: item.unit_price,
        unit_cost: item.unit_cost,
        total_price: item.total_price,
        total_cost: item.total_cost,
        profit: item.profit,
        supplier: item.supplier
      }))
    };
    
    res.json(data);
  } catch (error) {
    console.error('Error exporting order:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Statistics routes
app.get('/api/stats/clients', authenticateToken, async (req, res) => {
  try {
    // Get total clients
    const totalClients = await db.collection('clients').countDocuments();
    
    // Get clients by status
    const now = new Date();
    const oneMonthAgo = new Date(now);
    oneMonthAgo.setMonth(now.getMonth() - 1);
    
    const twoMonthsAgo = new Date(now);
    twoMonthsAgo.setMonth(now.getMonth() - 2);
    
    const threeMonthsAgo = new Date(now);
    threeMonthsAgo.setMonth(now.getMonth() - 3);
    
    const sixMonthsAgo = new Date(now);
    sixMonthsAgo.setMonth(now.getMonth() - 6);
    
    // Green: purchase in the last month
    const greenClients = await db.collection('clients').countDocuments({
      last_purchase: { $gte: oneMonthAgo }
    });
    
    // Yellow: purchase between 1-2 months ago
    const yellowClients = await db.collection('clients').countDocuments({
      last_purchase: { $lt: oneMonthAgo, $gte: twoMonthsAgo }
    });
    
    // Orange: purchase between 2-3 months ago
    const orangeClients = await db.collection('clients').countDocuments({
      last_purchase: { $lt: twoMonthsAgo, $gte: threeMonthsAgo }
    });
    
    // Black: purchase more than 6 months ago or never
    const blackClients = await db.collection('clients').countDocuments({
      $or: [
        { last_purchase: { $lt: sixMonthsAgo } },
        { last_purchase: null }
      ]
    });
    
    // Get clients by month
    const clientsByMonthPipeline = [
      {
        $group: {
          _id: {
            year: { $year: '$created_at' },
            month: { $month: '$created_at' }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: {
          '_id.year': 1,
          '_id.month': 1
        }
      }
    ];
    
    const clientsByMonth = await db.collection('clients').aggregate(clientsByMonthPipeline).toArray();
    
    res.json({
      totalClients,
      statusDistribution: {
        green: greenClients,
        yellow: yellowClients,
        orange: orangeClients,
        black: blackClients
      },
      clientsByMonth: clientsByMonth.map(item => ({
        year: item._id.year,
        month: item._id.month,
        count: item.count
      }))
    });
  } catch (error) {
    console.error('Error getting client stats:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

app.get('/api/stats/orders', authenticateToken, async (req, res) => {
  try {
    // Get total orders
    const totalOrders = await db.collection('orders').countDocuments();
    
    // Get orders by status
    const pendingOrders = await db.collection('orders').countDocuments({ status: 'pending' });
    const processingOrders = await db.collection('orders').countDocuments({ status: 'processing' });
    const completedOrders = await db.collection('orders').countDocuments({ status: 'completed' });
    const cancelledOrders = await db.collection('orders').countDocuments({ status: 'cancelled' });
    
    // Get total revenue
    const revenuePipeline = [
      {
        $group: {
          _id: null,
          total: { $sum: '$total_amount' }
        }
      }
    ];
    
    const revenueResult = await db.collection('orders').aggregate(revenuePipeline).toArray();
    const totalRevenue = revenueResult.length > 0 ? revenueResult[0].total : 0;
    
    // Get total profit
    const profitPipeline = [
      {
        $group: {
          _id: null,
          total: { $sum: '$profit' }
        }
      }
    ];
    
    const profitResult = await db.collection('orders').aggregate(profitPipeline).toArray();
    const totalProfit = profitResult.length > 0 ? profitResult[0].total : 0;
    
    // Get average profit margin
    const avgMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
    
    // Get orders by month
    const ordersByMonthPipeline = [
      {
        $group: {
          _id: {
            year: { $year: '$order_date' },
            month: { $month: '$order_date' }
          },
          count: { $sum: 1 },
          revenue: { $sum: '$total_amount' },
          profit: { $sum: '$profit' }
        }
      },
      {
        $sort: {
          '_id.year': 1,
          '_id.month': 1
        }
      }
    ];
    
    const ordersByMonth = await db.collection('orders').aggregate(ordersByMonthPipeline).toArray();
    
    res.json({
      totalOrders,
      statusDistribution: {
        pending: pendingOrders,
        processing: processingOrders,
        completed: completedOrders,
        cancelled: cancelledOrders
      },
      financials: {
        totalRevenue,
        totalProfit,
        avgMargin
      },
      ordersByMonth: ordersByMonth.map(item => ({
        year: item._id.year,
        month: item._id.month,
        count: item.count,
        revenue: item.revenue,
        profit: item.profit
      }))
    });
  } catch (error) {
    console.error('Error getting order stats:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Configuration test route
app.post('/api/config/test-connection', async (req, res) => {
  try {
    const { uri, dbName } = req.body;
    
    if (!uri) {
      return res.status(400).json({ message: 'MongoDB URI is required' });
    }
    
    // Test connection
    const client = new MongoClient(uri);
    await client.connect();
    
    // Test database access
    const testDb = client.db(dbName || 'test');
    await testDb.command({ ping: 1 });
    
    await client.close();
    
    res.json({ message: 'Connection successful' });
  } catch (error) {
    console.error('Error testing MongoDB connection:', error);
    res.status(500).json({ message: 'Connection failed', error: error.message });
  }
});

// Serve the SPA for any other route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
const PORT = process.env.PORT || 3000;

// Connect to MongoDB and start server
connectToMongoDB().then(connected => {
  if (connected) {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`Server running on port ${PORT}`);
    });
  } else {
    console.error('Failed to connect to MongoDB. Server not started.');
  }
});

module.exports = app;
