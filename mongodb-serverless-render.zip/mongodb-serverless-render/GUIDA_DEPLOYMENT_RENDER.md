# Guida al Deployment su Render per Client Pulse CRM con MongoDB

Questa guida dettagliata ti aiuterà a deployare il tuo gestionale clienti Client Pulse CRM con MongoDB su Render, una piattaforma di hosting moderna e affidabile.

## Indice
1. [Prerequisiti](#prerequisiti)
2. [Configurazione di MongoDB Atlas](#configurazione-di-mongodb-atlas)
3. [Deployment su Render](#deployment-su-render)
4. [Configurazione Post-Deployment](#configurazione-post-deployment)
5. [Accesso all'Applicazione](#accesso-allapplicazione)
6. [Risoluzione Problemi](#risoluzione-problemi)

## Prerequisiti

Prima di iniziare, assicurati di avere:
- Un account Render (puoi registrarti gratuitamente su [render.com](https://render.com))
- Un account MongoDB Atlas (puoi registrarti gratuitamente su [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas))
- Il pacchetto `mongodb-serverless-render.zip` che ti ho fornito

## Configurazione di MongoDB Atlas

1. **Crea un account MongoDB Atlas**:
   - Visita [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
   - Registrati per un account gratuito o accedi se ne hai già uno

2. **Crea un nuovo cluster**:
   - Seleziona il piano gratuito (Shared)
   - Scegli un provider cloud (AWS, Google Cloud o Azure) e una regione vicina ai tuoi utenti
   - Clicca su "Create Cluster" (la creazione potrebbe richiedere alcuni minuti)

3. **Configura l'accesso al database**:
   - Nella sezione "Security", clicca su "Database Access"
   - Clicca su "Add New Database User"
   - Scegli "Password" come metodo di autenticazione
   - Inserisci un nome utente e una password (salva queste credenziali in un luogo sicuro)
   - Assegna il ruolo "Read and Write to any database"
   - Clicca su "Add User"

4. **Configura l'accesso alla rete**:
   - Nella sezione "Security", clicca su "Network Access"
   - Clicca su "Add IP Address"
   - Per consentire l'accesso da Render, seleziona "Allow Access from Anywhere" (0.0.0.0/0)
   - Clicca su "Confirm"

5. **Ottieni l'URI di connessione**:
   - Nella dashboard del cluster, clicca su "Connect"
   - Seleziona "Connect your application"
   - Copia l'URI di connessione (sarà simile a `mongodb+srv://username:<password>@cluster0.xxxxx.mongodb.net/`)
   - Sostituisci `<password>` con la password del tuo utente database
   - Salva questo URI, lo utilizzerai durante il deployment su Render

## Deployment su Render

### Opzione 1: Deployment tramite Dashboard Render (Consigliato)

1. **Crea un account Render**:
   - Visita [render.com](https://render.com)
   - Registrati per un account gratuito o accedi se ne hai già uno

2. **Crea un nuovo Web Service**:
   - Dal dashboard di Render, clicca su "New" e seleziona "Web Service"
   - Scegli "Upload Files" per caricare direttamente i file

3. **Carica i file**:
   - Estrai il pacchetto `mongodb-serverless-render.zip` sul tuo computer
   - Comprimi nuovamente la cartella estratta
   - Carica il file .zip su Render
   - Render estrarrà automaticamente i file

4. **Configura il Web Service**:
   - **Nome**: `client-pulse-mongodb` (o un nome a tua scelta)
   - **Runtime**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`

5. **Configura le variabili d'ambiente**:
   - Scorri verso il basso fino alla sezione "Environment Variables"
   - Aggiungi le seguenti variabili:
     - `PORT`: `3000`
     - `MONGODB_URI`: [il tuo URI MongoDB Atlas]
     - `DB_NAME`: `clientPulseCRM`
     - `JWT_SECRET`: [una stringa segreta a tua scelta per la generazione dei token JWT]

6. **Avvia il deployment**:
   - Clicca su "Create Web Service"
   - Render inizierà il processo di build e deployment (potrebbe richiedere alcuni minuti)

### Opzione 2: Deployment tramite render.yaml (Avanzato)

1. **Prepara il file render.yaml**:
   - Nel pacchetto che ti ho fornito è incluso un file `render.yaml`
   - Questo file contiene la configurazione per il deployment automatico su Render

2. **Crea un nuovo Blueprint su Render**:
   - Dal dashboard di Render, clicca su "New" e seleziona "Blueprint"
   - Carica il file `render.yaml`
   - Segui le istruzioni per configurare il servizio

3. **Configura le variabili d'ambiente**:
   - Durante il processo di configurazione del Blueprint, ti verrà chiesto di inserire le variabili d'ambiente
   - Inserisci il tuo URI MongoDB Atlas per la variabile `MONGODB_URI`
   - Le altre variabili saranno configurate automaticamente

## Configurazione Post-Deployment

1. **Inizializza il database**:
   - Dopo il deployment, accedi all'URL fornito da Render seguito da `/api/init-demo`
   - Esempio: `https://client-pulse-mongodb.onrender.com/api/init-demo`
   - Questo endpoint eseguirà lo script `demo-setup.js` che popolerà il database con dati di esempio
   - Dovresti vedere un messaggio di conferma che indica il successo dell'inizializzazione

2. **Verifica lo stato dell'applicazione**:
   - Accedi all'URL fornito da Render seguito da `/api/health`
   - Esempio: `https://client-pulse-mongodb.onrender.com/api/health`
   - Dovresti vedere un messaggio JSON che indica che il server è in esecuzione

## Accesso all'Applicazione

1. **Accedi all'applicazione**:
   - Apri il browser e vai all'URL fornito da Render (es. `https://client-pulse-mongodb.onrender.com`)
   - Verrai reindirizzato alla pagina di login

2. **Credenziali di accesso predefinite**:
   - Email: `admin@clientpulse.it`
   - Password: `admin123`

3. **Esplora l'applicazione**:
   - Dopo il login, avrai accesso a tutte le funzionalità del gestionale clienti:
     - Dashboard generale con statistiche
     - Dashboard ordini con sistema di colorazione progressiva
     - Gestione completa dei clienti
     - Gestione avanzata degli ordini
     - Importazione/esportazione Excel
     - Generazione di conferme d'ordine

## Risoluzione Problemi

### Problemi di Connessione a MongoDB

1. **Verifica l'URI di connessione**:
   - Assicurati che l'URI sia corretto e contenga username e password corretti
   - Verifica che il nome del cluster sia corretto
   - Controlla che non ci siano spazi o caratteri speciali non codificati nell'URI

2. **Controlla le regole di accesso alla rete**:
   - Assicurati che l'opzione "Allow Access from Anywhere" sia attivata in MongoDB Atlas
   - In alternativa, aggiungi manualmente l'IP del tuo servizio Render

3. **Verifica i log di Render**:
   - Nella dashboard di Render, vai alla scheda "Logs" del tuo servizio
   - Cerca eventuali errori relativi alla connessione MongoDB

### Problemi con il Deployment

1. **Errori di build**:
   - Verifica che il comando di build (`npm install`) sia completato con successo
   - Controlla che tutte le dipendenze siano elencate nel file `package.json`

2. **Errori di avvio**:
   - Assicurati che il comando di avvio (`node server.js`) sia corretto
   - Verifica che tutte le variabili d'ambiente siano configurate correttamente

3. **Timeout durante il deployment**:
   - Render potrebbe avere timeout durante il deployment di applicazioni complesse
   - Prova a suddividere il processo in più fasi o a ottimizzare il codice

### Problemi con l'Applicazione

1. **Pagina bianca o errori JavaScript**:
   - Apri la console del browser per vedere eventuali errori
   - Verifica che tutti i file statici siano serviti correttamente

2. **Errori di autenticazione**:
   - Assicurati di utilizzare le credenziali corrette
   - Verifica che la variabile d'ambiente `JWT_SECRET` sia configurata correttamente

3. **Problemi con l'importazione/esportazione Excel**:
   - Verifica che la libreria `xlsx` sia installata correttamente
   - Controlla i permessi di accesso ai file temporanei su Render

---

Per ulteriore assistenza o domande, non esitare a contattarmi. Sono qui per aiutarti a ottenere il massimo dal tuo gestionale clienti!
