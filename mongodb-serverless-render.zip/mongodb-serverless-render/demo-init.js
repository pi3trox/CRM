// Script di inizializzazione per la demo online
// Questo script modifica il server.js per includere l'endpoint di health check e la popolazione del database demo

// Importa il modulo fs per la manipolazione dei file
const fs = require('fs');
const path = require('path');

// Percorso del file server.js
const serverFilePath = path.join(__dirname, 'server.js');

// Leggi il contenuto del file server.js
let serverContent = fs.readFileSync(serverFilePath, 'utf8');

// Aggiungi l'endpoint di health check prima della riga "// Start server"
if (!serverContent.includes('/api/health')) {
  const healthCheckCode = `
// Health check endpoint per Render
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'ok', message: 'Server is running' });
});

`;
  
  // Trova la posizione dove inserire il codice
  const startServerPosition = serverContent.indexOf('// Start server');
  
  if (startServerPosition !== -1) {
    // Inserisci il codice del health check
    serverContent = 
      serverContent.slice(0, startServerPosition) + 
      healthCheckCode + 
      serverContent.slice(startServerPosition);
    
    console.log('Endpoint di health check aggiunto al server.js');
  } else {
    console.error('Non è stato possibile trovare il punto di inserimento per il health check');
  }
}

// Importa il modulo di popolazione del database demo
if (!serverContent.includes('demo-setup')) {
  const demoSetupCode = `
// Importa il modulo di popolazione del database demo
const { populateDemoDatabase } = require('./demo-setup');

`;
  
  // Trova la posizione dove inserire il codice (dopo gli import)
  const lastImportPosition = serverContent.lastIndexOf('const');
  const nextLineAfterLastImport = serverContent.indexOf('\n', lastImportPosition) + 1;
  
  if (nextLineAfterLastImport !== 0) {
    // Inserisci il codice di import
    serverContent = 
      serverContent.slice(0, nextLineAfterLastImport) + 
      demoSetupCode + 
      serverContent.slice(nextLineAfterLastImport);
    
    console.log('Import del modulo demo-setup aggiunto al server.js');
  } else {
    console.error('Non è stato possibile trovare il punto di inserimento per l\'import');
  }
}

// Modifica la funzione connectToMongoDB per popolare il database demo
if (!serverContent.includes('populateDemoDatabase')) {
  // Trova la funzione connectToMongoDB
  const connectFunctionStart = serverContent.indexOf('async function connectToMongoDB()');
  const connectFunctionEnd = serverContent.indexOf('return false;', connectFunctionStart);
  const returnTruePosition = serverContent.lastIndexOf('return true;', connectFunctionEnd);
  
  if (returnTruePosition !== -1) {
    // Codice da inserire prima del return true
    const populateDbCode = `
    // Popola il database demo con dati di esempio
    console.log('Popolamento del database demo...');
    await populateDemoDatabase();
    console.log('Database demo popolato con successo');
    
    `;
    
    // Inserisci il codice prima del return true
    serverContent = 
      serverContent.slice(0, returnTruePosition) + 
      populateDbCode + 
      serverContent.slice(returnTruePosition);
    
    console.log('Chiamata a populateDemoDatabase aggiunta alla funzione connectToMongoDB');
  } else {
    console.error('Non è stato possibile trovare il punto di inserimento nella funzione connectToMongoDB');
  }
}

// Scrivi il contenuto modificato nel file server.js
fs.writeFileSync(serverFilePath, serverContent);
console.log('File server.js modificato con successo per la demo online');

// Crea un file README per la demo
const demoReadmePath = path.join(__dirname, 'DEMO_README.md');
const demoReadmeContent = `# Client Pulse CRM - Demo Online

Questa è una versione dimostrativa di Client Pulse CRM con MongoDB.

## Credenziali di accesso

- **Email**: admin@clientpulse.it
- **Password**: admin123

## Dati di esempio

Questa demo include:

- 5 clienti di esempio con diversi stati (verde, giallo, arancione, nero)
- Ordini di esempio per ciascun cliente
- Prodotti di esempio per ciascun ordine

## Funzionalità disponibili

- Dashboard generale con statistiche
- Dashboard ordini
- Gestione clienti
- Gestione ordini
- Importazione/esportazione Excel
- Sistema di colorazione progressiva

## Note

Questa è una versione dimostrativa. I dati vengono ripristinati periodicamente.
`;

fs.writeFileSync(demoReadmePath, demoReadmeContent);
console.log('File DEMO_README.md creato con successo');

console.log('Inizializzazione della demo online completata');
