# Guida all'Implementazione e Utilizzo di Client Pulse CRM con MongoDB

Questa guida dettagliata ti aiuterà a configurare, deployare e utilizzare la versione MongoDB del tuo gestionale clienti Client Pulse CRM.

## Indice
1. [Panoramica della Soluzione](#panoramica-della-soluzione)
2. [Requisiti di Sistema](#requisiti-di-sistema)
3. [Configurazione di MongoDB Atlas](#configurazione-di-mongodb-atlas)
4. [Installazione Locale](#installazione-locale)
5. [Deployment su Vercel](#deployment-su-vercel)
6. [Utilizzo dell'Applicazione](#utilizzo-dellapplicazione)
7. [Funzionalità Principali](#funzionalità-principali)
8. [Risoluzione Problemi](#risoluzione-problemi)

## Panoramica della Soluzione

La soluzione Client Pulse CRM con MongoDB è composta da:

- **Backend Serverless**: Un'API RESTful basata su Express.js che si connette a MongoDB
- **Frontend**: Un'interfaccia utente in HTML, CSS e JavaScript vanilla
- **Database**: MongoDB per l'archiviazione dei dati (sostituisce Supabase)

Questa soluzione mantiene tutte le funzionalità della versione originale, inclusa l'importazione/esportazione Excel, e aggiunge le nuove funzionalità richieste.

## Requisiti di Sistema

- Node.js 14.x o superiore
- Account MongoDB Atlas (gratuito per iniziare)
- Account Vercel (opzionale, per il deployment)

## Configurazione di MongoDB Atlas

1. **Crea un account MongoDB Atlas**:
   - Visita [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
   - Registrati per un account gratuito

2. **Crea un nuovo cluster**:
   - Seleziona il piano gratuito (Shared)
   - Scegli un provider cloud e una regione vicina ai tuoi utenti
   - Clicca su "Create Cluster"

3. **Configura l'accesso al database**:
   - Nella sezione "Security", clicca su "Database Access"
   - Aggiungi un nuovo utente con password
   - Assegna il ruolo "Read and Write to any database"

4. **Configura l'accesso alla rete**:
   - Nella sezione "Security", clicca su "Network Access"
   - Clicca su "Add IP Address"
   - Per lo sviluppo, puoi selezionare "Allow Access from Anywhere" (0.0.0.0/0)
   - Per la produzione, limita l'accesso agli IP specifici

5. **Ottieni l'URI di connessione**:
   - Nella dashboard del cluster, clicca su "Connect"
   - Seleziona "Connect your application"
   - Copia l'URI di connessione (sostituisci `<password>` con la password del tuo utente)

## Installazione Locale

1. **Estrai il file zip** della soluzione in una directory locale

2. **Configura le variabili d'ambiente**:
   - Copia il file `.env.example` in un nuovo file `.env`
   - Modifica il file `.env` con i tuoi dati:
     ```
     PORT=3000
     MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/
     DB_NAME=clientPulseCRM
     JWT_SECRET=la-tua-chiave-segreta-per-jwt
     ```

3. **Installa le dipendenze**:
   ```bash
   cd mongodb-serverless
   npm install
   ```

4. **Avvia il server**:
   ```bash
   npm start
   ```

5. **Accedi all'applicazione**:
   - Apri il browser e vai a `http://localhost:3000`
   - Al primo avvio, ti verrà chiesto di configurare la connessione all'API
   - Inserisci `http://localhost:3000/api` come URL dell'API

## Deployment su Vercel

1. **Installa Vercel CLI** (opzionale):
   ```bash
   npm install -g vercel
   ```

2. **Configura le variabili d'ambiente su Vercel**:
   - Accedi al tuo account Vercel
   - Vai a "Settings" > "Environment Variables"
   - Aggiungi le seguenti variabili:
     - `MONGODB_URI`: Il tuo URI di connessione MongoDB
     - `DB_NAME`: Il nome del tuo database
     - `JWT_SECRET`: Una chiave segreta per JWT

3. **Deploy tramite Vercel CLI**:
   ```bash
   cd mongodb-serverless
   vercel
   ```

4. **Deploy tramite Vercel Dashboard**:
   - Crea un nuovo progetto su Vercel
   - Collega il tuo repository Git o carica la directory del progetto
   - Configura le variabili d'ambiente come descritto sopra
   - Clicca su "Deploy"

5. **Configura il frontend**:
   - Dopo il deployment, accedi all'URL fornito da Vercel
   - Configura l'URL dell'API inserendo `https://tuo-progetto.vercel.app/api`

## Utilizzo dell'Applicazione

### Registrazione e Login

1. **Registrazione**:
   - Al primo utilizzo, clicca su "Registrati"
   - Compila il form con nome, email e password
   - Clicca su "Registrati"

2. **Login**:
   - Inserisci email e password
   - Clicca su "Accedi"

### Dashboard Generale

La dashboard generale mostra:
- Statistiche sui clienti
- Statistiche sugli ordini
- Clienti recenti
- Ordini recenti
- Sistema di colorazione progressiva per i clienti

### Gestione Clienti

- **Visualizza clienti**: Accedi alla lista completa dei clienti
- **Aggiungi cliente**: Compila il form con i dati del cliente
- **Modifica cliente**: Aggiorna i dati di un cliente esistente
- **Elimina cliente**: Rimuovi un cliente (solo se non ha ordini)
- **Importa/Esporta**: Importa clienti da Excel o esporta in Excel

### Gestione Ordini

- **Visualizza ordini**: Accedi alla lista completa degli ordini
- **Crea ordine**: Seleziona un cliente e aggiungi prodotti
- **Modifica ordine**: Aggiorna i dati di un ordine esistente
- **Elimina ordine**: Rimuovi un ordine e i suoi elementi
- **Genera conferma d'ordine**: Crea un documento PDF o Excel con i dettagli dell'ordine

## Funzionalità Principali

### Sistema di Colorazione Progressiva

I clienti sono classificati in base alla data dell'ultimo acquisto:
- **Verde**: Acquisto negli ultimi 30 giorni
- **Giallo**: Acquisto tra 30 e 60 giorni fa
- **Arancione**: Acquisto tra 60 e 90 giorni fa
- **Nero**: Nessun acquisto negli ultimi 90 giorni o mai

### Gestione Ordini Avanzata

Ogni ordine include:
- Codice prodotto
- Quantità
- Fornitore
- Prezzo di acquisto e vendita
- Date di acquisto e consegna
- Numero d'ordine del cliente
- Calcolo automatico del gap tra costo e prezzo di vendita

### Importazione/Esportazione Excel

- Importa clienti e ordini da file Excel
- Esporta dati in formato Excel
- Genera conferme d'ordine in Excel o PDF

## Risoluzione Problemi

### Problemi di Connessione a MongoDB

1. **Verifica l'URI di connessione**:
   - Assicurati che l'URI sia corretto e contenga username e password corretti
   - Verifica che il nome del cluster sia corretto

2. **Controlla le regole di accesso alla rete**:
   - Assicurati che l'IP del tuo server sia autorizzato ad accedere a MongoDB Atlas

3. **Verifica le credenziali utente**:
   - Controlla che l'utente abbia i permessi corretti sul database

### Problemi con il Frontend

1. **Errore di connessione all'API**:
   - Verifica che l'URL dell'API sia corretto
   - Controlla che il server backend sia in esecuzione
   - Verifica che non ci siano problemi CORS

2. **Pagina bianca o errori JavaScript**:
   - Apri la console del browser per vedere eventuali errori
   - Verifica che tutti i file JavaScript siano caricati correttamente

### Problemi con Vercel

1. **Errori di deployment**:
   - Controlla i log di build su Vercel
   - Verifica che tutte le variabili d'ambiente siano configurate correttamente

2. **Errori di runtime**:
   - Controlla i log delle funzioni serverless su Vercel
   - Verifica che MongoDB Atlas sia accessibile da Vercel

---

Per ulteriore assistenza o domande, non esitare a contattarmi. Sono qui per aiutarti a ottenere il massimo dal tuo gestionale clienti!
