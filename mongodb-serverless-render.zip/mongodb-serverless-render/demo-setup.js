// Configurazione MongoDB Atlas per la demo online
require('dotenv').config();
const { MongoClient } = require('mongodb');

// Credenziali MongoDB Atlas per la demo
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://demo-user:demo-password@demo-cluster.mongodb.net/';
const DB_NAME = process.env.DB_NAME || 'clientPulseCRM';

// Dati di esempio per la demo
const demoData = {
  clients: [
    {
      name: 'Rossi SRL',
      email: 'info@rossisrl.it',
      phone: '+39 02 1234567',
      address: 'Via Roma 123, Milano',
      notes: 'Cliente importante nel settore manifatturiero',
      status: 'active',
      last_purchase: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // 15 giorni fa
      created_at: new Date(),
      updated_at: new Date()
    },
    {
      name: 'Bianchi SpA',
      email: 'contatti@bianchispa.it',
      phone: '+39 06 7654321',
      address: 'Via Nazionale 45, Roma',
      notes: 'Distributore per il centro Italia',
      status: 'active',
      last_purchase: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000), // 45 giorni fa
      created_at: new Date(),
      updated_at: new Date()
    },
    {
      name: 'Verdi & Figli',
      email: 'amministrazione@verdiefigli.it',
      phone: '+39 011 9876543',
      address: 'Corso Vittorio 78, Torino',
      notes: 'Piccola azienda familiare',
      status: 'active',
      last_purchase: new Date(Date.now() - 75 * 24 * 60 * 60 * 1000), // 75 giorni fa
      created_at: new Date(),
      updated_at: new Date()
    },
    {
      name: 'Neri Costruzioni',
      email: 'info@nericostruzioni.it',
      phone: '+39 081 3456789',
      address: 'Via Vesuvio 22, Napoli',
      notes: 'Impresa edile in espansione',
      status: 'active',
      last_purchase: new Date(Date.now() - 120 * 24 * 60 * 60 * 1000), // 120 giorni fa
      created_at: new Date(),
      updated_at: new Date()
    },
    {
      name: 'Blu Tecnologie',
      email: 'supporto@blutecnologie.it',
      phone: '+39 055 8765432',
      address: 'Viale Innovazione 56, Firenze',
      notes: 'Startup tecnologica',
      status: 'active',
      last_purchase: null, // Mai acquistato
      created_at: new Date(),
      updated_at: new Date()
    }
  ],
  users: [
    {
      email: 'admin@clientpulse.it',
      password: '$2a$10$XFDQGfUd8Vz.W9hFAJfTIewxDH5hH5nNVZVmGBpHsZ0hhOTJQQzXe', // Password: admin123
      name: 'Amministratore Demo',
      created_at: new Date(),
      updated_at: new Date()
    }
  ]
};

// Funzione per popolare il database con dati di esempio
async function populateDemoDatabase() {
  let client;
  
  try {
    // Connessione a MongoDB Atlas
    client = new MongoClient(MONGODB_URI);
    await client.connect();
    console.log('Connesso a MongoDB Atlas');
    
    const db = client.db(DB_NAME);
    
    // Crea le collezioni se non esistono
    const collections = await db.listCollections().toArray();
    const collectionNames = collections.map(c => c.name);
    
    if (!collectionNames.includes('clients')) {
      await db.createCollection('clients');
    }
    
    if (!collectionNames.includes('users')) {
      await db.createCollection('users');
    }
    
    if (!collectionNames.includes('orders')) {
      await db.createCollection('orders');
    }
    
    if (!collectionNames.includes('orderItems')) {
      await db.createCollection('orderItems');
    }
    
    // Inserisci i clienti di esempio
    const clientsCollection = db.collection('clients');
    const clientsCount = await clientsCollection.countDocuments();
    
    if (clientsCount === 0) {
      const result = await clientsCollection.insertMany(demoData.clients);
      console.log(`${result.insertedCount} clienti inseriti`);
      
      // Crea ordini di esempio per i clienti
      const ordersCollection = db.collection('orders');
      const orderItemsCollection = db.collection('orderItems');
      
      const clients = await clientsCollection.find().toArray();
      
      for (const client of clients) {
        // Salta i clienti che non hanno mai acquistato
        if (!client.last_purchase) continue;
        
        // Crea 1-3 ordini per cliente
        const numOrders = Math.floor(Math.random() * 3) + 1;
        
        for (let i = 0; i < numOrders; i++) {
          const orderDate = new Date(client.last_purchase);
          orderDate.setDate(orderDate.getDate() - Math.floor(Math.random() * 10)); // Data casuale intorno all'ultimo acquisto
          
          const order = {
            client_id: client._id.toString(),
            order_number: `ORD-${Date.now()}-${i}`,
            order_date: orderDate,
            delivery_date: new Date(orderDate.getTime() + 15 * 24 * 60 * 60 * 1000), // 15 giorni dopo l'ordine
            status: ['pending', 'processing', 'completed'][Math.floor(Math.random() * 3)],
            total_amount: 0,
            total_cost: 0,
            profit: 0,
            notes: 'Ordine di esempio',
            created_at: new Date(),
            updated_at: new Date()
          };
          
          const orderResult = await ordersCollection.insertOne(order);
          const orderId = orderResult.insertedId.toString();
          
          // Crea 1-5 elementi per ordine
          const numItems = Math.floor(Math.random() * 5) + 1;
          let totalAmount = 0;
          let totalCost = 0;
          
          for (let j = 0; j < numItems; j++) {
            const quantity = Math.floor(Math.random() * 10) + 1;
            const unitPrice = Math.floor(Math.random() * 100) + 50;
            const unitCost = Math.floor(unitPrice * 0.7); // 30% di margine
            const totalPrice = quantity * unitPrice;
            const totalItemCost = quantity * unitCost;
            
            const item = {
              order_id: orderId,
              product_code: `PROD-${Math.floor(Math.random() * 1000) + 1}`,
              description: `Prodotto di esempio ${j + 1}`,
              quantity: quantity,
              unit_price: unitPrice,
              unit_cost: unitCost,
              total_price: totalPrice,
              total_cost: totalItemCost,
              profit: totalPrice - totalItemCost,
              supplier: ['Fornitore A', 'Fornitore B', 'Fornitore C'][Math.floor(Math.random() * 3)],
              created_at: new Date(),
              updated_at: new Date()
            };
            
            await orderItemsCollection.insertOne(item);
            
            totalAmount += totalPrice;
            totalCost += totalItemCost;
          }
          
          // Aggiorna i totali dell'ordine
          await ordersCollection.updateOne(
            { _id: orderResult.insertedId },
            {
              $set: {
                total_amount: totalAmount,
                total_cost: totalCost,
                profit: totalAmount - totalCost
              }
            }
          );
        }
      }
      
      console.log('Ordini e elementi ordine creati con successo');
    } else {
      console.log(`Il database contiene già ${clientsCount} clienti, salto l'inserimento`);
    }
    
    // Inserisci gli utenti di esempio
    const usersCollection = db.collection('users');
    const usersCount = await usersCollection.countDocuments();
    
    if (usersCount === 0) {
      const result = await usersCollection.insertMany(demoData.users);
      console.log(`${result.insertedCount} utenti inseriti`);
    } else {
      console.log(`Il database contiene già ${usersCount} utenti, salto l'inserimento`);
    }
    
    console.log('Database demo popolato con successo');
    return true;
  } catch (error) {
    console.error('Errore durante la popolazione del database demo:', error);
    return false;
  } finally {
    if (client) {
      await client.close();
      console.log('Connessione a MongoDB Atlas chiusa');
    }
  }
}

// Esporta la funzione
module.exports = { populateDemoDatabase };

// Se eseguito direttamente, popola il database
if (require.main === module) {
  populateDemoDatabase()
    .then(() => process.exit(0))
    .catch(error => {
      console.error(error);
      process.exit(1);
    });
}
