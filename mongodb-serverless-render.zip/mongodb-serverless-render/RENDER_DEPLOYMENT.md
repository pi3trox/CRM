# Configurazione per il deployment su Render

## Istruzioni per il deployment

1. Crea un account su Render (https://render.com)
2. Crea un nuovo Web Service
3. Collega il tuo repository GitHub o carica i file direttamente
4. Configura le seguenti impostazioni:
   - Nome: client-pulse-mongodb
   - Runtime: Node
   - Build Command: `npm install`
   - Start Command: `node server.js`
   - Variabili d'ambiente:
     - PORT: 3000
     - MONGODB_URI: (il tuo URI MongoDB Atlas)
     - DB_NAME: clientPulseCRM
     - JWT_SECRET: (una stringa segreta per JWT)

## Configurazione MongoDB Atlas

1. Crea un account MongoDB Atlas (https://www.mongodb.com/cloud/atlas)
2. Crea un nuovo cluster (puoi usare il piano gratuito)
3. Configura l'accesso al database:
   - Crea un utente database
   - Configura l'accesso alla rete (puoi consentire l'accesso da qualsiasi IP)
4. Ottieni l'URI di connessione e inseriscilo nelle variabili d'ambiente di Render

## File di configurazione

Questo repository include:
- `render.json` - Configurazione per il deployment automatico
- `health-check.js` - Endpoint per il monitoraggio dello stato dell'applicazione
- `demo-setup.js` - Script per popolare il database con dati di esempio

## Dopo il deployment

1. Accedi all'applicazione con:
   - Email: admin@clientpulse.it
   - Password: admin123
2. Verifica che tutte le funzionalità siano operative
3. Importa i tuoi dati o utilizza i dati di esempio
